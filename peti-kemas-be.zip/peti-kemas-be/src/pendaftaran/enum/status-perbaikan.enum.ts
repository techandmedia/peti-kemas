export enum StatusPerbaikan {
  DAFTAR = 'DAFTAR',
  ANTRI = 'ANTRI',
  PROSES = 'SEDANG PERBAIKAN',
  SELESAI = 'SELESAI',
}
